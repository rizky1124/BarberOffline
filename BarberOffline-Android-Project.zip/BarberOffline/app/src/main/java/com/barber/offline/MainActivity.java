package com.barber.offline;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView todayCount,todayIncome,monthIncome,history; android.content.SharedPreferences p;
    int adult=30000, child=25000;
    String money(int n){return String.format(java.util.Locale.US,"Rp%,d",n).replace(',','.');}
    String date(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    void addCut(String type,int price){String d=date(); int count=p.getInt("count_"+d,0)+1; int total=p.getInt("total_"+d,0)+price; int month=p.getInt("month_"+d.substring(0,7),0)+price; p.edit().putInt("count_"+d,count).putInt("total_"+d,total).putInt("month_"+d.substring(0,7),month).apply(); String old=p.getString("history",""); p.edit().putString("history",d+" • "+type+" • "+money(price)+"\n"+old).apply(); refresh(); Toast.makeText(this,"✓ "+type+" tercatat",Toast.LENGTH_SHORT).show();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.rgb(17,24,39));t.setPadding(8,8,8,8);return t;}
    Button btn(String text){Button b=new Button(this);b.setText(text);b.setTextSize(16);b.setAllCaps(false);b.setPadding(8,20,8,20);return b;}
    void refresh(){String d=date();todayCount.setText("Cukur hari ini\n"+p.getInt("count_"+d,0));todayIncome.setText("Pemasukan hari ini\n"+money(p.getInt("total_"+d,0)));monthIncome.setText("Bulan ini\n"+money(p.getInt("month_"+d.substring(0,7),0)));history.setText(p.getString("history","Belum ada transaksi."));}
    @Override public void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("data",0);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,20,16,16);root.setBackgroundColor(Color.rgb(244,245,247));
        TextView title=tv("💈 BARBERSHOP",24);title.setTextColor(Color.WHITE);title.setBackgroundColor(Color.rgb(17,24,39));title.setPadding(16,20,16,20);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("Tekan tombol setiap selesai cukur",14);root.addView(sub);
        Button a=btn("👨  CUKUR DEWASA   Rp30.000"); Button c=btn("👦  CUKUR ANAK      Rp25.000"); root.addView(a);root.addView(c);
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.VERTICAL);todayCount=tv("",17);todayIncome=tv("",17);monthIncome=tv("",17);stats.addView(todayCount);stats.addView(todayIncome);stats.addView(monthIncome);root.addView(stats);
        root.addView(tv("Riwayat transaksi",19)); ScrollView sv=new ScrollView(this);history=tv("",14);sv.addView(history);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        a.setOnClickListener(v->addCut("Cukur Dewasa",adult)); c.setOnClickListener(v->addCut("Cukur Anak",child)); setContentView(root);refresh(); }
}
